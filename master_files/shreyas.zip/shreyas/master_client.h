#ifndef _MASTER_CLIENT_H_
#define _MASTER_CLIENT_H_

#include <string>
#include <map>
#include <set>
#include "utilities.h"

enum class Opcode
{
    CLIENT_REQUEST,
    MAPPER_CONNECTION,
    REDUCER_CONNECTION,
    MAPPER_SUCCESS,
    MAPPER_FAILURE
};

class MasterClient
{
    int m_sock;

public:
    int m_port;
    std::string m_ip_addr;

    MasterClient(std::string ip = "", int p = -1): m_sock(-1), m_port(p), m_ip_addr(ip)
    {
        m_sock = util_connection_make(m_ip_addr, m_port);
    }

    int sock_get() { return m_sock; }

    int connect_as_mapper();
    int connect_as_reducer();
    int connect_as_client(Problem problem, std::string file_path);
};


#endif
