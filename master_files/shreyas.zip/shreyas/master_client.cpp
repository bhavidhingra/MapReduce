#include <string>
#include <cstdio>
#include <sys/socket.h>

#include "includes.h"
#include "master_client.h"
#include "utilities.h"

using namespace std;

int MasterClient::connect_as_client(Problem problem, string file_path)
{
    string client_opcode = to_string((int)Opcode::CLIENT_REQUEST);
    string problem_str = to_string((int)problem);
    string req = client_opcode + "$" + problem_str + "$" + file_path;
    util_write_to_sock(m_sock, req);
    return SUCCESS;
}


int MasterClient::connect_as_mapper()
{
    string req = to_string((int)Opcode::MAPPER_CONNECTION);
    util_write_to_sock(m_sock, req);
    return SUCCESS;
}


int MasterClient::connect_as_reducer()
{
    string req = to_string((int)Opcode::REDUCER_CONNECTION);
    util_write_to_sock(m_sock, req);
    return SUCCESS;
}
