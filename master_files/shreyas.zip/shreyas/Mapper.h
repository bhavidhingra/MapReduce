#ifndef MAPPER_H
#define MAPPER_H

#include <string>
#include <vector>

class Mapper
{
private:
    int mapper_socket;

public:
    Mapper(int s): mapper_socket(s) {}

    void init(int mapper_socket);
    int get_socket();
    void initiate_word_count_request(int job_id,
                                     int chunk_id,
                                     std::string file_path,
                                     off_t start_line,
                                     size_t num_lines,
                                     int no_of_reducers);

    void initiate_inverted_index_request(int job_id,
                                         int chunk_id,
                                         std::vector<std::string>& file_paths,
                                         std::vector<off_t>& start_line,
                                         std::vector<size_t>& num_lines,
                                         int no_of_reducers);

    std::string get_reply();
};

#endif
